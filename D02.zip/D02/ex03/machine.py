#!python3

from beverages import *
import random

class CoffeeMachine():
  drinks = 10

  def __init__(self) -> None:
    pass

  def repair(self):
    self.drinks = 10
    print("Coffe machine is repaired. Now you can serve 10 drinks more.")

  def serve(self, cup: HotBeverage):
    print(f"There is {self.drinks} drinks in machine...")
    if self.drinks == 0:
      raise self.BrokenMachineException()
    else:
      escolha = random.randint(0, 1)
      print("- Choice:", escolha)
      if escolha == 1:
        self.drinks -= 1
        return cup
      else:
        return self.EmptyCup() 


  class EmptyCup(HotBeverage):
    name = "empty cup"
    price = 0.90
    description_text = "An empty cup?! Gimme my money back!"


  class BrokenMachineException(Exception):
    message = "This coffee machine has to be repaired."

    def __init__(self) -> None:
      super().__init__(self.message)


if __name__ == '__main__':
  cafeteira = CoffeeMachine()
  bebida = HotBeverage()
  cafe = Coffee()
  cha = Tea()
  chocolate = Chocolate()
  cappucino = Cappuccino()

  try:
    for n in range(0, 25):
      print(cafeteira.serve(chocolate))
      print(cafeteira.serve(cha))
      print(cafeteira.serve(cappucino))
      print(cafeteira.serve(cafe))
      print(cafeteira.serve(chocolate))
      print(cafeteira.serve(cha))
  except Exception as error:
    print(cafeteira.BrokenMachineException().message)
    cafeteira.repair()
  
  print()

  try:
    for n in range(0, 25):
      print(cafeteira.serve(chocolate))
      print(cafeteira.serve(cha))
      print(cafeteira.serve(cappucino))
      print(cafeteira.serve(cafe))
      print(cafeteira.serve(chocolate))
      print(cafeteira.serve(cha))
  except Exception as error:
    print(cafeteira.BrokenMachineException().message)
    cafeteira.repair()
