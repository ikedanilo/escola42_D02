#!python3

import random as r
from beverages import *

class CoffeeMachine:
  broken = 0

  def __init__(self):
    pass 


  class EmptyCup(HotBeverage):
    name = "empty cup"
    price = 0.90
    description_text = "An empty cup?! Gimme my money back!"


  class BrokenMachineException(Exception):
    message = "This coffee machine has to be repaired." 

    def init(self):
      super().__init__(self.message)


  def repair(self):
    self.broken = 0
    print(f'machine repeared. Now you can serve 10 drinks more.')


  def serve(self, cup: HotBeverage):
    if (self.broken == 10):
      raise self.BrokenMachineException()
    else:
      randomic_choice = r.randint(0,1)
      self.broken += 1
      if randomic_choice == 0:
        return self.EmptyCup() 
      elif randomic_choice == 1:
          return (cup)


def newmachinetest():
  machine = CoffeeMachine()
  hotbev = HotBeverage()
  coffee = Coffee()
  tea = Tea()
  chocolate = Chocolate()
  cappuccino = Cappuccino()

  for i in range(6):
    try:
      print(i, str(machine.serve(hotbev)))
      print(i, str(machine.serve(coffee)))
    except:
      print(machine.BrokenMachineException().message)
      machine.repair()

  for i in range(6):
    try:
      print(i, str(machine.serve(chocolate)))
      print(i, str(machine.serve(cappuccino)))
    except:
      print(machine.BrokenMachineException().message)
      machine.repair()


if __name__ == '__main__':
  newmachinetest()