import re

dicionario = {'name': 'danilo', 'surname': 'messias'}
lista = ["        <h1>{name}</h1>","<h1>{surname}</h1>"]

for k, v in dicionario.items():
  for a in lista:
    print(k, a)
    comp = '{' + k + '}'
    x = re.findall(comp, a)
    if x:
      print("tem")
    else:
      print('nao tem')
