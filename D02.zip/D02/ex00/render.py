#!python3

import sys, os, re
from settings import *

def get_variables():
  dicionario = globals()
  # print(dicionario)
  return dicionario


def chk_file(arg):
  total_parameters = len(arg)
  if total_parameters == 2:
    input = arg[1]
    if input.endswith(".template"):
      try:
        with open(input, "r") as file:
          print(f"{input} file found!")
          return True
      except:
        print(f"{input} file not found :(")
        return False
    else:
      print(f"{input} doesn't have '.template' extension.")
  else:
    print(f"Arguments = {total_parameters} : wrong number of arguments.")
    return False
    
  
def create_html(template_file, html_file):
  chk = chk_file(sys.argv)
  if chk is True:

    dicionario_template = get_variables()
    # print(dicionario_template)

    lista_temp = []
    with open(template_file, 'r') as file:
      lista_temp = file.readlines()

    # print(lista_temp)

    with open(html_file, 'w+') as file:
      for e in lista_temp:
        for k, v in dicionario_template.items():
          comp = '{' + k + '}'
          if comp in e:
            e = e.replace(comp, v)
        file.write(e)
      print(f"{html_file} generated!")


# PROGRAMA PRINCIPAL
create_html(sys.argv[1], 'file.html')
