#!python3

class HotBeverage():
  price = 0.30
  name = "hot beverage"
  description_text = "Just some hot water in a cup."

  def description(self):
    return self.description_text

  def __str__(self) -> str:
    return f"\
    name: {self.name}\n\
    price: {self.price:.2f}\n\
    description: {self.description()}\n\
    "

class Coffee(HotBeverage):
  price = 0.40
  name = "coffee"
  description_text = "A coffee, to stay awake."

class Tea(HotBeverage):
  name = "tea"

class Chocolate(HotBeverage):
  price = 0.50
  name = "chocolate"
  description_text = "Chocolate, sweet chocolate..."

class Cappuccino(HotBeverage):
  price = 0.45
  name = "cappuccino"
  description_text = "Un po’ di Italia nella sua tazza!"


if __name__ == '__main__':
  refri = HotBeverage()
  cafe = Coffee()
  cha = Tea()
  chocolate = Chocolate()
  capuccino = Cappuccino()
  
  # print(refri.price)
  # print(refri.name)
  # print(refri.description_text)

  print(refri.__str__())
  print(cafe.__str__())
  print(cha.__str__())
  print(chocolate.__str__())
  print(capuccino.__str__())
  